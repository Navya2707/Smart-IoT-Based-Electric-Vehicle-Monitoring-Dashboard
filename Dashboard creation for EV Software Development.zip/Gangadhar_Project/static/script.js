// DOM Elements
const batteryLevel = document.getElementById('battery-level');
const batteryPercentage = document.getElementById('battery-percentage');
const voltageDisplay = document.getElementById('voltage');
const percentageDisplay = document.getElementById('percentage');
const canvas = document.getElementById('battery-chart');
const ctx = canvas.getContext('2d');

// Function to update battery level
function updateBattery(level, voltage) {
    // Ensure level is between 0 and 100
    level = Math.max(0, Math.min(100, level));

    // Update battery level width
    batteryLevel.style.width = `${level}%`;

    // Update battery percentage text
    batteryPercentage.textContent = `${level}%`;

    // Update voltage and percentage displays
    voltageDisplay.textContent = `${voltage}V`;
    percentageDisplay.textContent = `${level}%`;

    // Change battery color based on level
    if (level <= 20) {
        batteryLevel.style.backgroundColor = 'red';
    } else if (level <= 50) {
        batteryLevel.style.backgroundColor = 'orange';
    } else {
        batteryLevel.style.backgroundColor = 'green';
    }

    // Update chart
    drawChart(level);
}

// Function to draw a simple bar chart
function drawChart(level) {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear canvas
    ctx.fillStyle = '#007bff';
    ctx.fillRect(10, canvas.height - level * 2, 50, level * 2); // Draw bar
    ctx.fillStyle = '#333';
    ctx.font = '14px Arial';
    ctx.fillText(`${level}%`, 20, canvas.height - level * 2 - 10); // Add text
}

// Function to fetch data from the server
async function fetchData() {
    try {
        const response = await fetch('/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ voltage: 0, percentage: 0 }), // Default values
        });

        const data = await response.json();
        console.log('Received Data:', data);

        // Update the UI with the received data
        updateBattery(data.percentage, data.voltage);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

// Fetch data periodically (e.g., every 5 seconds)
setInterval(fetchData, 5000);

// Initialize with 0% battery
updateBattery(0, 0);